blacklist = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_,.><{}[]|\\\'"\r\n\t@&; try chr'
blacklist_kw = ["assert", "raise", "async", "def", "class", "import", ":=", "/0"]

inp = input("OMFG a pyjail!!! > ").splitlines()[0].strip()

import sys, io
sys.stdin = io.StringIO()

if not (inp.isprintable() and len(inp) < 50) or \
        any(char in blacklist for char in inp) or \
        any(kw in inp for kw in blacklist_kw):
    print("Nuh uhh this pyjail doesn't like your attempt")
    exit()

try:
    code = compile(inp, '', 'eval')
except:
    print("Nuh uhh your attempt is bad")
    exit()

exec(code, {'__builtins__': None}, {'open': open})