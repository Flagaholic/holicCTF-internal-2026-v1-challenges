#!/usr/bin/env sh
set -eu
cd -- "$(dirname -- "$0")"

draw() {
    printf '\033[2J\033[H%s\n' "$1"
    sleep 0.08
}

printf '\033[?25l'
trap 'printf "\033[?25h"' EXIT HUP INT TERM

for round in 1 2; do
    draw '   ♪
  \o/
   |
  / \'
    draw '      ♪
   o/
  /|
  / \'
    draw ' ♪
\o
 |\
/ \'
done

printf '\033[2J\033[H'
printf 'Never gonna give you flag.\n\n'
printf 'Recovery result: '
cat ./definitely_not_the_flag.txt
printf 'Backup recovery result: '
cat ./flag_backup_FINAL_REAL.txt
printf 'Integrity check result: '
cat ./recovery_checksum.txt
printf '\nOfficial recovery tutorial:\n'
printf 'https://www.youtube.com/watch?v=dQw4w9WgXcQ\n'
