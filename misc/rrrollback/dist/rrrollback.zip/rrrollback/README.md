# r1ck_r0llb4ck

I accidentally committed the flag, but don't worry.
I rolled it back, so Git definitely forgot it.

Run ./get_flag.sh for the totally legitimate recovery tool.

Flag format: `holic{...}`
