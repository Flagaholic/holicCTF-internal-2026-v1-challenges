blacklist = '0123456789abcdfghijklmqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_,.\\\'"\r\n\t'
blacklist_kw = ["assert", "raise", "flag"]

inp = input("OMG a pyjail!!! > ").splitlines()[0].strip()

if not (inp.isprintable() and len(inp) < 50) or \
        any(char in blacklist for char in inp) or \
        any(kw in inp for kw in blacklist_kw):
    print("Nuh uhh this pyjail doesn't like your attempt")
    exit()

try:
    code = compile(inp, '', 'eval')
except:
    print("Nuh uhh your attempt is bad")
    exit()

exec(code, {'__builtins__': None}, {'open': open})