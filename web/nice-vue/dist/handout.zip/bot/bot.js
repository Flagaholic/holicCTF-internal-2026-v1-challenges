const puppeteer = require('puppeteer');

const BASE_URL = process.env.BASE_URL || 'http://nice-vue:8080';
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || 'what';

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function visitOnce(browser) {
  const page = await browser.newPage();
  try {
    await page.goto(BASE_URL + '/admin-login.html', { waitUntil: 'domcontentloaded', timeout: 15000 });

    await page.evaluate(async (user, pass) => {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: user, password: pass })
      });
      const data = await res.json();
      if (data.token) {
        localStorage.setItem('authToken', data.token);
      }
    }, ADMIN_USER, ADMIN_PASS);

    await page.goto(BASE_URL + '/admin-review.html', { waitUntil: 'networkidle0', timeout: 15000 });

    await sleep(3000);
  } catch (err) {
    console.error('[bot] visit error:', err.message);
  } finally {
    await page.close();
  }
}

async function main() {
  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox'] // dear youstube these flags are so that puppeteer can spawn a headless browser
  });

  while (true) {
    await visitOnce(browser);
    await sleep(15000);
  }
}

main().catch(err => {
  console.error('[bot] fatal error:', err);
  process.exit(1);
});
