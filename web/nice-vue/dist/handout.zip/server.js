const express = require('express');
const path = require('path');
const crypto = require('crypto');

const app = express();
app.disable('x-powered-by');
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 8080;
const ADMIN_USER = process.env.ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASS || crypto.randomBytes(64).toString('hex');
const FLAG = process.env.FLAG || 'holic{FakeFlag_LMAO}';

const listings = [
  {
    id: 1,
    title: 'Cliffside house',
    price: '$4,250,000',
    location: 'Somewhere near coast',
    blurb: 'Wake up to breathtaking views of the ocean. Or fog. Honestly, mostly fog.',
    image: '/images/cliff.jpg'
  },
  {
    id: 2,
    title: 'Skyline Mirage',
    price: '$2,900,000',
    location: 'Probably uptown in china',
    blurb: 'House made of alumunumu, control panel, dry and wet bathroom, floor to ceiling windows to see idk',
    image: '/images/skyline.jpg'
  },
  {
    id: 3,
    title: 'Fjord Cottage',
    price: '$1,675,000',
    location: 'North of somewhere there',
    blurb: 'Panoramic fjord views so gud you will forget the nearest seven eleven is three hong kongs away.',
    image: '/images/fjord.jpg'
  },
  {
    id: 4,
    title: 'Mount Everview',
    price: '$5,800,000',
    location: 'High Up',
    blurb: 'Unobstructed mountain views guaranteed, view that big rock embedded deep into the earth called a big hill',
    image: '/images/mount.jpg'
  },
  {
    id: 5,
    title: 'Horizon Estate',
    price: '$980,000',
    location: 'Very Flat, Very Wide',
    blurb: 'Views that go on forever, because there is genuinely nothing else out here.',
    image: '/images/horizon.jpg'
  },
  {
    id: 6,
    title: 'Lakeside Manor',
    price: '$3,150,000',
    location: 'By The Water',
    blurb: 'Wake up to a mirror-still lake. Jet ski noise not included in this description, but definitely included irl.',
    image: '/images/lake.jpg'
  }
];

let reviewIdCounter = 1;
const reviews = [];

const validAdminTokens = new Map();

const DENYLIST = [
  '<script', 'onerror', 'onload', 'javascript:', '<img', '<svg', '<iframe',
  'alert(', 'document.cookie', '<object', '<embed'
];

function filterMessage(message) {
  const lower = message.toLowerCase();
  if (message.length > 500) {
    return { ok: false, reason: 'message too long' };
  }
  if (message.includes('<') || message.includes('>')) {
    return { ok: false, reason: 'blocked' };
  }
  for (const bad of DENYLIST) {
    if (lower.includes(bad)) {
      return { ok: false, reason: 'blocked' };
    }
  }
  return { ok: true };
}

const loginAttempts = new Map();
const LOGIN_WINDOW_MS = 180 * 1000;
const LOGIN_MAX_ATTEMPTS = 8;

function checkLoginRateLimit(ip) {
  const now = Date.now();
  const entry = loginAttempts.get(ip);
  if (!entry || now - entry.windowStart > LOGIN_WINDOW_MS) {
    loginAttempts.set(ip, { count: 0, windowStart: now });
    return true;
  }
  return entry.count < LOGIN_MAX_ATTEMPTS;
}

function recordFailedLogin(ip) {
  const entry = loginAttempts.get(ip);
  if (entry) entry.count += 1;
}

function requireAdmin(req, res, next) {
  const auth = req.headers['authorization'] || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  if (!token || !validAdminTokens.has(token)) {
    return res.status(401).json({ error: 'unauthorized' });
  }
  next();
}

app.get('/api/listings', (req, res) => {
  res.json(listings);
});

app.get('/api/listings/:id', (req, res) => {
  const listing = listings.find(l => l.id === Number(req.params.id));
  if (!listing) return res.status(404).json({ error: 'not found' });
  res.json(listing);
});

app.get('/api/listings/:id/reviews', (req, res) => {
  const listingId = Number(req.params.id);
  res.json(reviews.filter(r => r.listingId === listingId));
});

app.post('/api/listings/:id/reviews', (req, res) => {
  const listingId = Number(req.params.id);
  const listing = listings.find(l => l.id === listingId);
  if (!listing) return res.status(404).json({ error: 'listing not found' });

  const { name, message } = req.body || {};
  if (!name || !message || typeof name !== 'string' || typeof message !== 'string') {
    return res.status(400).json({ error: 'name and message are required' });
  }
  if (name.length > 80) {
    return res.status(400).json({ error: 'name too long' });
  }

  const check = filterMessage(message);
  if (!check.ok) {
    return res.status(400).json({ error: 'your review was flagged by our moderation filter'});
  }

  const review = {
    id: reviewIdCounter++,
    listingId,
    name,
    message,
    createdAt: new Date().toISOString()
  };
  reviews.push(review);
  res.status(201).json(review);
});

app.post('/api/admin/login', (req, res) => {
  const ip = req.ip;
  if (!checkLoginRateLimit(ip)) {
    return res.status(429).json({ error: 'too many attempts, try again later' });
  }

  const { username, password } = req.body || {};
  if (username === ADMIN_USER && password === ADMIN_PASS) {
    const token = crypto.randomBytes(24).toString('hex');
    validAdminTokens.set(token, { issuedAt: Date.now() });
    return res.json({ token });
  }
  recordFailedLogin(ip);
  res.status(401).json({ error: 'invalid credentials' });
});

app.get('/api/admin/reviews', requireAdmin, (req, res) => {
  res.json(reviews);
});

app.get('/api/admin/flag', requireAdmin, (req, res) => {
  res.json({ flag: FLAG });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'internal server error' });
});

app.listen(PORT, () => {
  console.log(`Nice Vue: Revenge running on port ${PORT}`);
});
