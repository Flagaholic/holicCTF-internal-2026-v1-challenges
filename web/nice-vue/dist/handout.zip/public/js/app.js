function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function getQueryParam(name) {
  return new URLSearchParams(window.location.search).get(name);
}

async function loadListingsGrid() {
  const grid = document.getElementById('listings-grid');
  if (!grid) return;
  const res = await fetch('/api/listings');
  const listings = await res.json();
  grid.innerHTML = listings.map(l => `
    <div class="card">
      <img src="${l.image}" alt="${escapeHtml(l.title)}"/>
      <div class="body">
        <h3>${escapeHtml(l.title)}</h3>
        <div class="price">${escapeHtml(l.price)}</div>
        <div class="location">${escapeHtml(l.location)}</div>
        <p class="blurb">${escapeHtml(l.blurb)}</p>
        <a class="view-link" href="/listing.html?id=${l.id}">View property &amp; reviews &rarr;</a>
      </div>
    </div>
  `).join('');
}

async function loadListingDetail() {
  const container = document.getElementById('listing-detail');
  if (!container) return;
  const id = getQueryParam('id');
  const res = await fetch(`/api/listings/${id}`);
  if (!res.ok) {
    container.innerHTML = '<p>Listing not found. Even our 404 page has a nice view, probably.</p>';
    return;
  }
  const l = await res.json();
  document.title = `${l.title} - Nice Vue`;
  container.innerHTML = `
    <div class="listing-hero">
      <img src="${l.image}" alt="${escapeHtml(l.title)}"/>
    </div>
    <h1 class="listing-title">${escapeHtml(l.title)}</h1>
    <div class="listing-meta">${escapeHtml(l.location)}</div>
    <div class="listing-price">${escapeHtml(l.price)}</div>
    <p class="listing-blurb">${escapeHtml(l.blurb)}</p>
  `;
  document.getElementById('review-listing-id').value = id;
  loadReviews(id);
}

async function loadReviews(listingId) {
  const list = document.getElementById('reviews-list');
  if (!list) return;
  const res = await fetch(`/api/listings/${listingId}/reviews`);
  const reviews = await res.json();
  if (reviews.length === 0) {
    list.innerHTML = '<p style="color:#999;font-size:13px;">No reviews yet. Be the first to comment on the view!</p>';
    return;
  }
  list.innerHTML = reviews.map(r => `
    <div class="review-card">
      <div class="rname">${escapeHtml(r.name)}</div>
      <div class="rbody">${escapeHtml(r.message)}</div>
    </div>
  `).join('');
}

async function handleReviewSubmit(event) {
  event.preventDefault();
  const form = event.target;
  const listingId = form.querySelector('#review-listing-id').value;
  const name = form.querySelector('#review-name').value;
  const message = form.querySelector('#review-message').value;
  const errorBox = document.getElementById('review-error');
  const successBox = document.getElementById('review-success');
  errorBox.textContent = '';
  successBox.textContent = '';

  const res = await fetch(`/api/listings/${listingId}/reviews`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, message })
  });
  const data = await res.json();
  if (!res.ok) {
    errorBox.textContent = data.error + (data.reason ? ` (${data.reason})` : '');
    return;
  }
  successBox.textContent = 'Thanks! Your review has been submitted and will appear once its reviewed.';
  form.reset();
  loadReviews(listingId);
}

document.addEventListener('DOMContentLoaded', () => {
  loadListingsGrid();
  loadListingDetail();
  const form = document.getElementById('review-form');
  if (form) form.addEventListener('submit', handleReviewSubmit);
});
