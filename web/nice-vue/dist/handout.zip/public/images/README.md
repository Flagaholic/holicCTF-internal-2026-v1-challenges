Drop listing photos here, named to match `server.js`:

- sunset.jpg
- dusk.jpg
- dawn.jpg
- alpine.jpg
- prairie.jpg
- lake.jpg

Any image format works as long as the filename (and extension) in
`server.js`'s `image` field for each listing matches what you place here.
