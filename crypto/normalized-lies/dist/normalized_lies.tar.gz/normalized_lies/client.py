from __future__ import annotations

import argparse
import socket
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("host")
    parser.add_argument("port", type=int)
    parser.add_argument("payload", type=Path)
    args = parser.parse_args()

    line = args.payload.read_text().strip().encode() + b"\n"
    chunks: list[bytes] = []
    received = b""
    with socket.create_connection((args.host, args.port), timeout=10) as sock:
        sock.settimeout(10)
        while b"object> " not in received:
            data = sock.recv(4096)
            if not data:
                break
            chunks.append(data)
            received += data
        sock.sendall(line)
        while True:
            try:
                data = sock.recv(4096)
            except socket.timeout:
                break
            if not data:
                break
            chunks.append(data)
    print(b"".join(chunks).decode("utf-8", "replace"), end="")


if __name__ == "__main__":
    main()
