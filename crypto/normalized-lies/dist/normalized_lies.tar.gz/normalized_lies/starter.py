from __future__ import annotations

import hashlib
import subprocess
import tempfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main() -> None:
    raw = zlib.decompress((ROOT / "assets" / "release.obj").read_bytes())
    header, _, body = raw.partition(b"\0")
    print(header.decode())
    print(hashlib.sha1(raw).hexdigest())
    print()
    print(body.decode("utf-8", "replace"))

    with tempfile.TemporaryDirectory() as td:
        repo = Path(td) / "repo.git"
        subprocess.run(
            ["git", "-c", "init.defaultBranch=main", "clone", "--bare", "--quiet", str(ROOT / "assets" / "repository.bundle"), str(repo)],
            check=True,
        )
        refs = subprocess.run(
            ["git", "--git-dir", str(repo), "show-ref"],
            stdout=subprocess.PIPE,
            check=True,
        ).stdout.decode()
        print(refs, end="")


if __name__ == "__main__":
    main()
